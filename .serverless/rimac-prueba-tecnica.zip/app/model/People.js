module.exports = class People{
    nombre;
    altura;
    masa;
    colorCabello;
    colorPiel;
    colorOjos;
    añoNacimiento;
    genero;
    mundoNatal;
    peliculas;
    especies;
    vehiculos;
    navesEstelares;
    creado;
    editado;
    url;
}